package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */
import java.util.ArrayList;

public class Product
{
    private double price, xcoordinate, ycoordinate;
    private int identificationnumber, quantity, rating;
    private String category, name;
    private ArrayList <String> reviews;

    public Product (double p, double xc, double yc, int in, int q, int ra, String c, String n, ArrayList <String> re)
    {
        price = p;
        if (price < 0.0)
        {
            price = 0.0;
        }
        xcoordinate = xc;
        ycoordinate = yc;
        identificationnumber = in;
        quantity = q;
        rating = ra;
        if (rating < 0)
        {
            rating = 0;
        }
        else if (rating > 10)
        {
            rating = 10;
        }
        category = c;
        name = n;
        reviews = re;
    }

    public void AddAReview (String review)
    {
        reviews.add (review);
    }

    public void Rate (int r)
    {
        rating = r;
        if (rating < 0)
        {
            rating = 0;
        }
        else if (rating > 10)
        {
            rating = 10;
        }
    }

    public double GetPrice ()
    {
        return price;
    }

    public void SetPrice (double p)
    {
        price = p;
    }

    public void SetXCoordinate (double xc)
    {
        xcoordinate = xc;
    }

    public double GetXCoordinate ()
    {
        return xcoordinate;
    }

    public void SetYCoordinate (double yc)
    {
        ycoordinate = yc;
    }

    public double GetYCoordinate ()
    {
        return ycoordinate;
    }

    public String GetName ()
    {
        return name;
    }
}