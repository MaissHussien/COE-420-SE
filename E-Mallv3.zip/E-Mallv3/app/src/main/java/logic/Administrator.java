package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class Administrator extends User
{
    Shop []shops= new Shop[10];
    public Administrator (Shop [] s, String e, String p, String u) throws NoSuchAlgorithmException
    {
        super (e, p, u);
    }

    public void AddAProduct (Product p, Shop s)
    {
        int index;
        for (index = 0; index < shops.length; index = index + 1)
        {
            if (shops [index].equals (s))
            {
                shops [index].GetProducts ().add (p);
                break;
            }
        }
    }

    public void RemoveAProduct (Product p, Shop s)
    {
        int index;
        for (index = 0; index < shops.length; index = index + 1)
        {
            if (shops [index].equals (s))
            {
                shops [index].GetProducts ().remove (p);
                break;
            }
        }
    }

    public void SetProductsList (ArrayList <Product> p, Shop s)
    {
        int index;
        for (index = 0; index < shops.length; index = index + 1)
        {
            if (shops [index].equals (s))
            {
                shops [index].SetProducts (p);
                break;
            }
        }
    }
}
