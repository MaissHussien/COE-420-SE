package logic;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.ahmad.fragments.LoginLogoutContainer;
import com.firebase.client.AuthData;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.util.Map;


/**
 * Created by Ahmad on 4/9/2016.
 */
public class UserDatabase extends android.app.Application {
    private Customer loggedinCustomer;
    Sorter x = new Sorter();
    private static Administrator LoggedinAdmin;
    Firebase mRef;
    private Context context;
    String email;
    String password;
    Intent i;

    String s;


    String signupURL = "https://glaring-heat-440.firebaseio.com/?page=Auth";


    LoginLogoutContainer main;


    String loginUsername;
    String loginPassword;
    String registerLogin;
    String registerPassword;

    String text1;


    public String getCustomer() {
        if (loggedinCustomer != null)
            return loggedinCustomer.getEMail();
        else return null;
    }


    @Override
    public void onCreate() {


        super.onCreate();
        Firebase.setAndroidContext(this);


        mRef = new Firebase(signupURL);
       /* mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = dataSnapshot.getValue(Map.class);
                String ahmad = map.get("Ahmad");


                 i = new Intent(UserDatabase.this, MainActivity.class);


            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });*/

    }

    public void signupAttempt(final String email, final String password, final Context c) throws InterruptedException {
        this.email = email;
        this.password = password;
        context = c;

        mRef = new Firebase(signupURL);

        /*SignupToServer signupToServer = new SignupToServer(email, password, c);
        signupToServer.start();

        signupToServer.join();*/

        System.out.println("aaaaaaaaaaaaa");
        mRef.createUser(email, password, new Firebase.ValueResultHandler<Map<String, Object>>() {


            @Override
            public void onSuccess(Map<String, Object> result) {



                Toast.makeText(context, "Thank you for registering!",
                        Toast.LENGTH_LONG).show();


                mRef.authWithPassword(email, password, new Firebase.AuthResultHandler() {
                    @Override
                    public void onAuthenticated(AuthData authData) {

                       loggedinCustomer= new Customer(email, password, "User");
                        //Toast.makeText(context, "You successfully logged in.",
                          //      Toast.LENGTH_LONG).show();
                        // Go to the Home class
                        // the problem is firebase is asynchronous.
                        // The android java code will keep moving on and does not wait
                        // for the firebase database to respond so it will fail to detect whether
                        // the user is logged in or not to go to the Home page activity.
                        // Therefore, unfortunately, we have to switch to the home activity inside the DB class.


                    }


                    @Override
                    public void onAuthenticationError(FirebaseError firebaseError) {
                        // there was an error
                        //  Toast.makeText(getApplicationContext(), "Username or password is incorrect",
                        //        Toast.LENGTH_LONG).show();

                        //i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        //Bundle bundle = new Bundle();
                        //bundle.putString("email", "Login Error");
                        //i.putExtras(bundle);
                        //startActivity(i);
                        System.out.println("Auth Error");
                        s = "You could not login for some reason!";

                    }
                });

            }

            @Override
            public void onError(FirebaseError firebaseError) {
                Toast.makeText(context, "Please provide valid email and password.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
/*
    private class SignupToServer extends Thread {


        private Context context;
        String email;
        String password;

        public SignupToServer(final String email1, final String password1, Context c1) {

            //mRef = new Firebase(signupURL);

            email=email1;
            password=password1;
            context=c1;
        }

        public void run() {
            mRef.createUser(email, password, new Firebase.ValueResultHandler<Map<String, Object>>() {
                @Override
                public void onSuccess(Map<String, Object> result) {



                    Toast.makeText(context, "Thank you for registering!",
                            Toast.LENGTH_LONG).show();


                    mRef.authWithPassword(email, password, new Firebase.AuthResultHandler() {
                        @Override
                        public void onAuthenticated(AuthData authData) {


                            loggedinCustomer = new Customer(email, password, "User");
                            Toast.makeText(context, "You successfully logged in.",
                                    Toast.LENGTH_LONG).show();

                            // Go to the Home class
                            // the problem is firebase is asynchronous.
                            // The android java code will keep moving on and does not wait
                            // for the firebase database to respond so it will fail to detect whether
                            // the user is logged in or not to go to the Home page activity.
                            // Therefore, unfortunately, we have to switch to the home activity inside the DB class.
                            startActivity(new Intent(context, Home.class));

                        }


                        @Override
                        public void onAuthenticationError(FirebaseError firebaseError) {
                            // there was an error
                            //  Toast.makeText(getApplicationContext(), "Username or password is incorrect",
                            //        Toast.LENGTH_LONG).show();

                            //i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            //Bundle bundle = new Bundle();
                            //bundle.putString("email", "Login Error");
                            //i.putExtras(bundle);
                            //startActivity(i);
                            System.out.println("Auth Error");
                            s = "You could not login for some reason!";

                        }
                    });


                }

                @Override
                public void onError(FirebaseError firebaseError) {
                    Toast.makeText(context, "Please provide valid email and password.",
                            Toast.LENGTH_LONG).show();
                }
            });

        }
    }
}*/
/*
                @Override
                public void onError(FirebaseError firebaseError) {
                    Toast.makeText(context, "Please provide valid email and password.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }
            // Get a BluetoothSocket to connect with the given BluetoothDevice
            try {
                // MY_UUID is the app's UUID string, also used by the server code
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) { }
            mmSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it will slow down the connection
            btAdapter.cancelDiscovery();

            try {
                // Connect the device through the socket. This will block
                // until it succeeds or throws an exception
                mmSocket.connect();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and get out
                try {
                    mmSocket.close();
                } catch (IOException closeException) { }
                return;
            }

            // Do work to manage the connection (in a separate thread)

            mHandler.obtainMessage(SUCCESS_CONNECT,mmSocket).sendToTarget();
            ConnectedThread connected= new ConnectedThread(mmSocket);
            connected.start();
        }


    }


}*/
