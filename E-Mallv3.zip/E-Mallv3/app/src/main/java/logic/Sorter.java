package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */
public class Sorter
{
    public static Product [] SortByPrice (Product [] products)
    {
        boolean swappingoccurred;
        int index1, index2;
        Product temp;
        for (index1 = 0; index1 < products.length; index1 = index1 + 1)
        {
            swappingoccurred = false;
            for (index2 = 0; index2 < products.length; index2 = index2 + 1)
            {
                if (products [index2].GetPrice () > products [index2 + 1].GetPrice ())
                {
                    temp = products [index2];
                    products [index2] = products [index2 + 1];
                    products [index2 + 1] = temp;
                    swappingoccurred = true;
                }
            }
            if (!swappingoccurred)
            {
                break;
            }
        }
        return products;
    }

    public static Product [] SortByLocation (Product [] products)
    {
        boolean swappingoccurred;
        CurrentLocation currentlocation = new CurrentLocation ();
        double distance1, distance2;
        int index1, index2;
        Product temp;
        for (index1 = 0; index1 < products.length; index1 = index1 + 1)
        {
            swappingoccurred = false;
            for (index2 = 0; index2 < products.length; index2 = index2 + 1)
            {
                distance1 = Math.sqrt ((Math.pow ((products [index2].GetXCoordinate () - currentlocation.GetXCoordinate ()), 2.0)) + (Math.pow (products [index2].GetYCoordinate () - currentlocation.GetYCoordinate (), 2.0)));
                distance2 = Math.sqrt ((Math.pow ((products [index2 + 1].GetXCoordinate () - currentlocation.GetXCoordinate ()), 2.0)) + (Math.pow (products [index2 + 1].GetYCoordinate () - currentlocation.GetYCoordinate (), 2.0)));
                if (distance1 > distance2)
                {
                    temp = products [index2];
                    products [index2] = products [index2 + 1];
                    products [index2 + 1] = temp;
                    swappingoccurred = true;
                }
            }
            if (!swappingoccurred)
            {
                break;
            }
        }
        return products;
    }
}