package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */

import java.util.ArrayList;
import java.util.Arrays;

public class Customer extends User
{
    private ArrayList <Product> wishlist;

     public Customer (String e, String p, String u)
    {
        super ( e, p, u);
        wishlist = new ArrayList <Product> ();
    }

    /*public ArrayList <Product> FindAProduct (String productsname, String preference)
    {
        ArrayList <Product> results = new ArrayList <Product> ();
        int index1, index2;
        for (index1 = 0; index1 < shops.length; index1 = index1 + 1)
        {
            for (index2 = 0; index2 < shops [index1].GetProducts ().size (); index2 = index2 + 1)
            {
                if (productsname.equals (shops [index1].GetProducts ().get (index2).GetName ()))
                {
                    results.add (shops [index1].GetProducts ().get (index2));
                }
            }
        }
        if (preference == "Sort By Price")
        {
            results = (ArrayList <Product>) Arrays.asList (Sorter.SortByPrice ((Product[]) results.toArray ()));
        }
        else if (preference == "Sort By Location")
        {
            results = (ArrayList <Product>) Arrays.asList (Sorter.SortByLocation ((Product[]) results.toArray ()));
        }
        return results;
    }

    public void WriteAReview (Product p, String review)
    {
        int index1, index2;
        for (index1 = 0; index1 < shops.length; index1 = index1 + 1)
        {
            for (index2 = 0; index2 < shops [index1].GetProducts ().size (); index2 = index2 + 1)
            {
                if (p.equals (shops [index1].GetProducts ().get (index2)))
                {
                    shops [index1].GetProducts ().get (index2).AddAReview (review);
                }
            }
        }
    }
*/
    public void AddAProductToAWishList (Product p)
    {
        wishlist.add (p);
    }
}