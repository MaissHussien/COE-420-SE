package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */
import java.util.ArrayList;

public class Shop
{
    private double xcoordinate, ycoordinate;
    private String name;
    private ArrayList <Product> products;

    public Shop (double xc, double yc, String n, ArrayList <Product> p)
    {
        int index;
        xcoordinate = xc;
        ycoordinate = yc;
        name = n;
        products = p;
        for (index = 0; index < products.size (); index = index + 1)
        {
            products.get (index).SetXCoordinate (xcoordinate);
            products.get (index).SetYCoordinate (ycoordinate);
        }
    }

    public void SetXCoordinate (double xc)
    {
        xcoordinate = xc;
    }

    public double GetXCoordinate ()
    {
        return xcoordinate;
    }

    public void SetYCoordinate (double yc)
    {
        ycoordinate = yc;
    }

    public double GetYCoordinate ()
    {
        return ycoordinate;
    }

    public void SetProducts (ArrayList <Product> p)
    {
        products = p;
    }

    public ArrayList <Product> GetProducts ()
    {
        return products;
    }
}