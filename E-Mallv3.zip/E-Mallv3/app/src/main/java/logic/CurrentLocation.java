package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */
import java.util.Random;

public class CurrentLocation implements Runnable
{
    private double xcoordinate, ycoordinate;

    public CurrentLocation ()
    {
        super ();
        Thread thread = new Thread (this);
        thread.start ();
    }

    public void run ()
    {
        Random randomnumbergeneratort = new Random ();
        while (true)
        {
            xcoordinate = randomnumbergeneratort.nextDouble () * 180;
            ycoordinate = randomnumbergeneratort.nextDouble () * 180;
        }
    }

    public double GetXCoordinate ()
    {
        return xcoordinate;
    }

    public double GetYCoordinate ()
    {
        return ycoordinate;
    }
}