package logic;

import android.content.Context;

import com.example.ahmad.fragments.LoginLogoutContainer;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Map;

/**
 * Created by Ahmad on 4/9/2016.
 */
public class ProductDatabase extends android.app.Application {
    Firebase mRef;
    private static Context context;


    String productsURL="https://glaring-heat-440.firebaseio.com/?page=Auth";


    LoginLogoutContainer main;





    @Override
    public void onCreate()
    {

        super.onCreate();
        Firebase.setAndroidContext(this);


        mRef= new Firebase(productsURL);
       /* mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = dataSnapshot.getValue(Map.class);
                String ahmad = map.get("Ahmad");


                 i = new Intent(UserDatabase.this, MainActivity.class);


            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });*/

    }

    public void searchAttempt(final String username, final String password, Context c)
    {

        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = dataSnapshot.getValue(Map.class);
                String ahmad = map.get("Ahmad");





            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }



}
