package logic;

/**
 * Created by Ahmad on 4/8/2016.
 */
import java.math.BigInteger;
import java.security.MessageDigest;


public abstract class User
{

    private String email, password, username;
    public User ( String e, String p, String u)
    {
        email = e;
        password = p;
        username = u;
    }

  /*  private String GetSHA256Hashing (String string)
    {
        BigInteger number;
        byte [] bytes;
        int index;
        MessageDigest sha256 = MessageDigest.getInstance ("SHA-256");
        String hashedstring = "";
        bytes = sha256.digest (string.getBytes ());
        number = new BigInteger (1, bytes);
        for (index = 0; index < bytes.length; index = index + 1)
        {
            hashedstring = hashedstring + (Integer.toString ((bytes [index] & 0xFF) + 0x100, 16).substring (1));
        }
        return hashedstring;
    }*/

    public void changeEMail (String e)
    {
        email = e;
    }

    public String getEMail ()
    {
        return email;
    }

  /*  public void ChangePassword (String oldpassword, String newpassword) throws NoSuchAlgorithmException
    {
        if (password.equals (GetSHA256Hashing (oldpassword)))
        {
            password = GetSHA256Hashing (newpassword);
        }
    }*/

    public String getUsername ()
    {
        return username;
    }
}