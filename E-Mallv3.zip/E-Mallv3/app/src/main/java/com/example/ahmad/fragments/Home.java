package com.example.ahmad.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import logic.UserDatabase;

public class Home extends AppCompatActivity {

    //Variables declarations section start ----------
    Spinner spinner;
    String category;
    int spinnerPos;
    ArrayAdapter<CharSequence> adapter;

    TopPartFragment1 topPart1;
    TopPartFragment2 topPart2;
    FragmentManager fragmentManager;
    UserDatabase userdb=new UserDatabase();
    //Variables declarations section end -------------


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // the drop down list section START --------------
        spinner = (Spinner) findViewById(R.id.spinner);
        adapter = ArrayAdapter.createFromResource(this, R.array.Category, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = (String) parent.getItemAtPosition(position);
                System.out.println(category);
                spinnerPos = position;
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        // the drop down list section END --------------

        // Top part of the home page can show the login button if the user is not logged in
        // Top part of the home page can also show the email address and the wish list if the user is logged in
        // UserDatabase has a static variable for the customer and getCustomer() will check if that variable is null.
        // we need to check if getCustomer() returns null, then the user is not logged in
        // and we show TopPartFragment1. If it returns a String then the user is logged in
        // and we need to show TopPartFragment2
        System.out.println("Customer!!!! -----" + userdb.getCustomer());

        fragmentManager = getSupportFragmentManager();
        if (userdb.getCustomer() == null) {
            topPart1 = new TopPartFragment1();

            fragmentManager.
                    beginTransaction().
                    replace(R.id.fragment_container, topPart1) //The fragment container for either TopPartFragment1 or 2
                    .commit();
        }
        else
        {
            topPart2 = new TopPartFragment2();


            fragmentManager.
                    beginTransaction().
                    replace(R.id.fragment_container, topPart2) //The fragment container for either TopPartFragment1 or 2
                    .commit();
        }
    }
    public void goToLogin(View v){
        // if the user clicks the Login button from the TopPartFragment1, he will immediately go to the login page
        startActivity(new Intent(getApplicationContext(), LoginLogoutContainer.class));
    }


    public void searchAttempt(View v)
    {
        startActivity(new Intent(getApplicationContext(), StoresFound.class));
    }

}
