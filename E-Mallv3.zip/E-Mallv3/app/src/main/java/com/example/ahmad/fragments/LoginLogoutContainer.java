package com.example.ahmad.fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import logic.UserDatabase;

public class LoginLogoutContainer extends AppCompatActivity {


    EditText emailSignup;
    EditText passwordSignup;
    Bundle loggedinBundle;


    String URL="https://glaring-heat-440.firebaseio.com/";
    String text;
    LoginFragment login;
    SignupFragment signup;
    FragmentManager fragmentManager;
    UserDatabase userdb = new UserDatabase();;
    SharedPreferences pref;



        public void goToLogin(View view) {
            //get Instance of Main Activity Class that generated this fragment

            //call the switchme function of the running main class
            switchme("login");
        }

    public void goToSignup(View view){
        //get Instance of Main Activity Class that generated this fragment

        //call the switchme function of the running main class
        switchme("signup");
    }

    public void destroyMe(View view){
        Intent loggedinIntent = new Intent(LoginLogoutContainer.this, Home.class );
        loggedinBundle.putBoolean("isLoggedin()",true);
        startActivity(new Intent(getApplicationContext(), Home.class));
        System.out.println(userdb.getCustomer());
    }

    private void destroyFragment() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        if(fragment != null)
            getSupportFragmentManager().beginTransaction().remove(fragment).commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);




        System.out.println("lol");
        loggedinBundle= new Bundle();
        loggedinBundle.putBoolean("isLoggedin", false);




      login= new LoginFragment();
      fragmentManager = getSupportFragmentManager();

      /*  fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container,login,"A");*/
        fragmentManager.
                beginTransaction().
                replace(R.id.fragment_container,login)
                .commit();

    }
    public void showMessage(View v)
    {
        Bundle bundle = getIntent().getExtras();
        String message;
                message= "nothing";
              message=  bundle.getString("email");
        System.out.println(message);

    }

    public void signUp(View v) throws InterruptedException {

      //  emailSignup= (EditText)findViewById(R.id.editText_EmailSignup);
      //  passwordSignup= (EditText)findViewById(R.id.editText_PasswordSignup);
        SignupFragment fragment1 = (SignupFragment)getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        View frag=fragment1.getView();
        emailSignup =(EditText) frag.findViewById(R.id.editText_EmailSignup);
        passwordSignup = (EditText) frag.findViewById(R.id.editText_PasswordSignup);
       String x=emailSignup.getText().toString();
        String y=passwordSignup.getText().toString();
        System.out.println(x + y);
        userdb.signupAttempt(x, y, LoginLogoutContainer.this);
        // check if the static Customer object in the UserDatabase class if it is null or not
        // if it is null that means the user is not logged in and we wont proceed to the Home page

       /* try {
            Thread.sleep(20000);                 //1000 milliseconds is one second.
        } catch(InterruptedException ex) {
            Thread.currentThread().interrupt();
        }*/


    }

    //Database Part start --------
    public void update(String text)
    {
        this.text=text;
        System.out.println(this.text);
    }
    //Database Part end -----------
    public void switchme(String name){
        switch(name){
            case "login": if(this.login == null) {
                login = new LoginFragment();
            }

                fragmentManager.
                        beginTransaction().
                        replace(R.id.fragment_container,login)
                        .commit();
                break;
            case "signup":
                if(this.signup == null){
                    signup=new SignupFragment();
                }

                fragmentManager.
                        beginTransaction().
                        replace(R.id.fragment_container,signup)
                        .commit();
                break;


            default:
                if(this.login == null){
                    login= new LoginFragment();
                }

                fragmentManager.
                        beginTransaction().
                        replace(R.id.fragment_container,signup)
                        .commit();
                break;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
